 <!-- Breadcrumb Section Start -->
 <div class="section-padding breadcrumb" data-bg-image="/images/header.png">
        <div class="container">
            <div class="row">
                <div class="col-12 align-items-center text-center">
                    <!-- Breadcrumb Wrapper Start -->
                    <div class="breadcrumb-wrapper">
                        <h1 class="title">Milestone</h1>
                        <ul class="breadcrumb-list">
                            <li><a href="\">Home</a></li>
                            <li><span>Milestone</span></li>
                        </ul>
                    </div>
                    <!-- Breadcrumb Wrapper End -->
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section End -->
    <div class="container mt-5 pump">
        <h1 class="marg">Milestone</h1>
     </div>

     <div class="container mt-5 mb-5">
        <div class="row ir">
            <img src="/images/about/milestone.png" style="width:70%;">
        </div>
     </div>