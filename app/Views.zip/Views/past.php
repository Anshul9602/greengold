 <!-- Breadcrumb Section Start -->
 <div class="section-padding breadcrumb" data-bg-image="/images/header.png">
        <div class="container">
            <div class="row">
                <div class="col-12 align-items-center text-center">
                    <!-- Breadcrumb Wrapper Start -->
                    <div class="breadcrumb-wrapper">
                        <h1 class="title">Previous Projects</h1>
                        <ul class="breadcrumb-list">
                            <li><a href="\">Home</a></li>
                            <li><span>Previous Projects</span></li>
                        </ul>
                    </div>
                    <!-- Breadcrumb Wrapper End -->
                     </div>
                     </div>
                     </div>
                     </div>
                     <div class="container mt-5 mb-5">
    <div class="row">
        <div class="col-md-12 marg">
            <img src="/images/past/past9.png">
        </div>
       
        <div class="col-md-4 sm-12 marg">
            <img src="/images/past/pasta.png">
        </div>
        <div class="col-md-4 sm-12 marg">
            <img src="/images/past/pastb.png">
        </div>
        <div class="col-md-4 sm-12 marg">
            <img src="/images/past/pastc.png">
        </div>
        <div class="col-md-4 sm-12 marg">
            <img src="/images/past/pastd.png">
        </div>
        <div class="col-md-4 sm-12 marg">
            <img src="/images/past/paste.png">
        </div>
        <div class="col-md-4 sm-12 marg">
            <img src="/images/past/pastf.png">
        </div>
        <div class="col-md-6 sm-12 marg">
            <img src="/images/past/pastg.png">
        </div>
        <div class="col-md-6 sm-12 marg">
            <img src="/images/past/pasth.png">
        </div>
        <div class="col-md-4 sm-12 marg">
            <img src="/images/past/pasti.png">
        </div>
        <div class="col-md-4 sm-12 marg">
            <img src="/images/past/pastj.png">
        </div>
        <div class="col-md-4 sm-12 marg">
            <img src="/images/past/pastk.png">
        </div>
        <div class="col-md-4 sm-12 marg">
            <img src="/images/past/pastl.png">
        </div>
        <div class="col-md-4 sm-12 marg">
            <img src="/images/past/pastm.png">
        </div>
        <div class="col-md-4 sm-12 marg">
            <img src="/images/past/pastn.png">
        </div>
        <div class="col-md-6 sm-12 marg">
            <img src="/images/past/pasto.png">
        </div>
        <div class="col-md-6 sm-12 marg">
            <img src="/images/past/pastp.png">
        </div>
        <div class="col-md-4 sm-12 marg">
            <img src="/images/past/pastq.png">
        </div>
        <div class="col-md-4 sm-12 marg">
            <img src="/images/past/pastr.png">
        </div>
        <div class="col-md-4 sm-12 marg">
            <img src="/images/past/pasts.png">
        </div>
    </div>
</div>
                     