 <!-- Breadcrumb Section Start -->
 <div class="section-padding breadcrumb" data-bg-image="<?php echo base_url(''); ?>/images/header.png">
        <div class="container">
            <div class="row">
                <div class="col-12 align-items-center text-center">
                    <!-- Breadcrumb Wrapper Start -->
                    <div class="breadcrumb-wrapper">
                        <h1 class="title">Finished
                        </h1>
                        <ul class="breadcrumb-list">
                            <li><a href="\">Home</a></li>
                            <li><span>Finished
                            </span></li>
                        </ul>
                    </div>
                    <!-- Breadcrumb Wrapper End -->
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section End -->


     <div class="container mt-5">
        <!-- <div class="row">
            <div class="col-md-6 sm-12 gen">
                <img src="/images/weserve/weserve1.png">
                 <a href="weserve1"><h4 class="margs">Institutions</h4></a>
            </div>
            <div class="col-md-6 sm-12 gen">
                <img src="/images/weserve/weserve2.png">
                <a href="weserve2"><h4 class="margs">Real Estate</h4></a>
            </div>
            <div class="col-md-6 sm-12 gen">
                <img src="/images/weserve/weserve3.png">
                <a href="weserve3"><h4 class="margs">Industrials</h4></a>
            </div>
            <div class="col-md-6 sm-12 gen">
                <img src="/images/weserve/weserve4.png">
                <a href="weserve4"><h4 class="margs">Communities & Municipalities</h4></a>
            </div>
            </div> -->
            </div>