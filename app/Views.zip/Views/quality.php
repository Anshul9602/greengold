 <!-- Breadcrumb Section Start -->
 <div class="section-padding breadcrumb" data-bg-image="/images/header.png">
        <div class="container">
            <div class="row">
                <div class="col-12 align-items-center text-center">
                    <!-- Breadcrumb Wrapper Start -->
                    <div class="breadcrumb-wrapper">
                        <h1 class="title">Quality and Compliance</h1>
                        <ul class="breadcrumb-list">
                            <li><a href="\">Home</a></li>
                            <li><a href="\">About</a></li>
                            <li><span>Quality and Compliance</span></li>
                        </ul>
                    </div>
                    <!-- Breadcrumb Wrapper End -->
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section End -->
    <div class="container mt-5 pump">
        <h1 class="marg">Quality and Compliance</h1>
        <p class="marg">Our honest business standards & transparent deals are enabling us in steadily making way to the platform of success by offering high quality products at most competitive prices keeping in mind that the total cost of ownership for the end user must not go high. We always adhere to the best & most suitable manufacturing or service standards & make sure that the product delivered to our end customer must add value to their system. We are 100% compliance eccentric company whether it is do with rules & regulations or ethical code of conduct.</p>
     </div>
     <div class="container mt-5">
        <div class="row ir">
            <img src="/images/about/qualityabout.png" style="width:80%;">
        </div>
     </div>
     <div class="container mt-5 mb-5 pump">
        <p class="marg">KSP expects legally and ethically impeccable conduct from all of its employees in daily business operations, as the way they carry out their duties affects the company’s reputation.</p>
     </div>
