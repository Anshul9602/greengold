

    <!-- Funfact Section Start -->
    <!-- <div class="section-padding funfact" data-bg-image="/images/funfact/funfact-bg.png">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 wow fadeIn" fadeIndata-wow-duration=".1s" data-wow-delay=".1s">
                    
                    <div class="heading-one">
                        <span class="heading-one-subtitle">We are JSC</span>
                        <h2 class="heading-one-title">We Are Leading The Industry</h2>
                        <p>Jaguar Steel and Coal Pte Ltd. is headquartered in Singapore and is a leading International Brokerage cum Trading House, dealing in various segments of the Metals and Steel Industry having our forte in Ferrous Scrap, Non- Ferrous Scrap like Stainless Steel Scrap, Aluminium, Copper, Brass, Lead,Zinc, Semi- Finished Steel like Slabs, Billets, Finished Steel like HR coils, CR Coils & Galvanized Coils etc in both containers and break bulk vessel. We play a pivotal role in the steel industry, acting as a trading intermediary and value-adding service provider. JSC's services span every step in the Metals and Steel supply chain. We seek to ensure a consistent and competitive supply of essential commodities to Metals & Steel Industry worldwide.We are now in the process of signing long term contracts with Iron Ore and Coal mines as well.</p>
                    </div>
                    
                </div>
                <div class="col-lg-6">
                    <div class="about-counter">
                        <div class="about-counter-2 wow fadeIn" fadeIndata-wow-duration=".1s" data-wow-delay=".1s">
                            <div class="funfact-inner">
                                <span class="odometer" data-count-to="20"></span>
                                <span class="increment">+</span>

                            </div>
                            <span class="about-counter-title">Years Of <br> Experience</span>
                        </div>
                        <div class="about-counter-2 wow fadeIn" fadeIndata-wow-duration=".01s" data-wow-delay=".1s">
                            <div class="funfact-inner">
                                <span class="odometer" data-count-to="500"></span>
                                <br><span class="increment">+</span>

                            </div>
                            <span class="about-counter-title">PROJECTS <br> COMPLETED</span>
                        </div>
                        <div class="about-counter-2 wow fadeIn" fadeIndata-wow-duration=".1s" data-wow-delay=".1s">
                            <div class="funfact-inner">
                                <span class="odometer" data-count-to="70"></span>
                                <span class="niktext">%</span>
                            </div>
                            <span class="about-counter-title">REDUCTION IN OPERATIONAL COSTS</span>
                        </div>
                        <div class="about-counter-2 wow fadeIn" fadeIndata-wow-duration=".01s" data-wow-delay=".1s">
                            <div class="funfact-inner">
                                <span class="odometer" data-count-to="200"></span>
                                <span class="increment">+</span>
                            </div>
                            <span class="about-counter-title"> CLIENTS <br> SERVED</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <!-- Funfact Section End -->

    <!-- About Creative Section Start -->
    
    

   

    <!-- Testimonial Section Start -->
    <!-- <div class="section-padding testimonial-two scene">
        <div class="container">
            <div class="row">
                <div class="col-12 wow fadeIn" fadeIndata-wow-duration=".1s" data-wow-delay=".1s">
        
                    <div class="heading-one">
                        <span class="heading-one-subtitle">Testimonials</span>
                        <h2 class="heading-one-title">What People Say</h2>
                    </div>
                
                </div>
            </div>

            <div class="row">
                <div class="col-12 position-relative wow fadeIn" fadeIndata-wow-duration=".1s" data-wow-delay=".1s">
                    <div class="testimonialtwo">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                
                                <div class="testimonial-two-single">
                                    <div class="quote gradient-1">
                                        <img src="/images/testimonial/quote.png" alt="QuoteIcon">
                                    </div>
                                    
                                     <img src="/images/testimonial/lalit_testimonial.jpg">
                                    
                                </div>
                            
                            </div>
                            <div class="swiper-slide">
                            
                                <div class="testimonial-two-single">
                                    <div class="quote gradient-1">
                                        <img src="/images/testimonial/quote.png" alt="QuoteIcon">
                                    </div>
                                    
                                    <img src="/images/testimonial/tata_testimonial.jpg">
                                </div>
                        
                            </div>
                            <div class="swiper-slide">
                                
                                <div class="testimonial-two-single">
                                    <div class="quote gradient-1">
                                        <img src="/images/testimonial/quote.png" alt="QuoteIcon">
                                    </div>
                                    
                                    <img src="/images/testimonial/ready_testimonial.jpg">
                                </div>
                    
                            </div>
                            <div class="swiper-slide">
                            
                                <div class="testimonial-two-single">
                                    <div class="quote gradient-1">
                                        <img src="/images/testimonial/quote.png" alt="QuoteIcon">
                                    </div>
                                    <img src="/images/testimonial/sdmh_testimonial.jpg">
                                    
                                </div>
                            
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-two-arrow">
                        <div class="swiper-arrow-long">
                            <div class="testimonial-slider-button-prev prev-button">
                                <img class="arrow-1" src="/images/slider/arrow-1.png" alt="ArrowImage">
                                <img class="arrow-2" src="/images/slider/arrow-2.png" alt="ArrowImage">
                            </div>
                            <div class="testimonial-slider-button-next next-button">
                                <img class="arrow-1" src="/images/slider/arrow-1.png" alt="ArrowImage">
                                <img class="arrow-2" src="/images/slider/arrow-2.png" alt="ArrowImage">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

       
    </div> -->
    <!-- Testimonial Section End -->

