 <!-- Breadcrumb Section Start -->
 <div class="section-padding breadcrumb" data-bg-image="/images/header.png">
        <div class="container">
            <div class="row">
                <div class="col-12 align-items-center text-center">
                    <!-- Breadcrumb Wrapper Start -->
                    <div class="breadcrumb-wrapper">
                        <h1 class="title">Our Support Partners</h1>
                        <ul class="breadcrumb-list">
                            <li><a href="\">Home</a></li>
                            <li><span>Our Support Partners</span></li>
                        </ul>
                    </div>
                    <!-- Breadcrumb Wrapper End -->
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section End -->
     <!----------------Partners------------------------
------------------------------------------------->
<div class="service section-padding position-relative">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 wow fadeIn" fadeIndata-wow-duration=".1s" data-wow-delay=".1s">
                    <!-- Heading Start -->
                    <div class="heading-one text-center">
                        <span class="heading-one-subtitle">Our Support</span>
                        <h2 class="heading-one-title">Partners</h2><br><br><br>
                    </div>
                    <!-- Heading End -->
                </div>

                <div class="col-md-2 sm-12 ir ir rig marg">
<img src="/images/partner/partner5.png">
                </div>
                <div class="col-md-2 sm-12 ir ir rig marg">
<img src="/images/partner/partner6.png">
                </div>
                <div class="col-md-2 sm-12 ir ir rig marg">
<img src="/images/partner/partner7.png">
                </div>
                <div class="col-md-2 sm-12 ir ir rig marg">
<img src="/images/partner/partner8.png">
                </div>
                <div class="col-md-2 sm-12 ir ir rig marg">
<img src="/images/partner/partner9.png">
                </div>
                </div>
            </div>
            </div>
            </div>
<!----------------------Partners end--------------
------------------------------------------------->